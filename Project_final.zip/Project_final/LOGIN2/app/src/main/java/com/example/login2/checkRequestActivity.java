package com.example.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class checkRequestActivity extends AppCompatActivity {
    TextView requestCheck;
    String requestList ="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_request);

            requestCheck = findViewById(R.id.requestCheck);

        for (int i = 0; i < BranchList.branches.size(); i++) {
            if (LogSucActivity.name.equals(BranchList.branches.get(i).branchName)) {
                for(int j = 0; j<BranchList.branches.get(i).mailbox.size();j++){
                requestList += (j+1)+". "+BranchList.branches.get(i).mailbox.get(j);

                requestList += "\n";
                }
            }
            }

        if(requestList ==""){
            Toast.makeText(getApplicationContext(), "The request list is empty.", Toast.LENGTH_LONG).show();
        }

        requestCheck.setText(requestList);

        }
}