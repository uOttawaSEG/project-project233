package com.example.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class requestActivity extends AppCompatActivity {
    EditText requestedService;
    EditText form;
    EditText doc;
    Button submit;
    String requestContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);

        requestedService = findViewById(R.id.requestedService);;
        form = findViewById(R.id.form);;
        doc = findViewById(R.id.doc);;
        submit = findViewById(R.id.submit);;

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(requestedService.getText()==null||form.getText()==null||doc.getText()==null){
                    Toast.makeText(getApplicationContext(), "Make sure you entered all three required information.", Toast.LENGTH_LONG).show();
                }
                else{

                    requestContent = CusSucActivity.CusName+","+requestedService.getText().toString()+","+ form.getText().toString()+","+doc.getText().toString();

                    for (int i = 0; i < BranchList.branches.size(); i++) {
                        if (CusSucActivity.selectedBranchName.equals(BranchList.branches.get(i).branchName)) {
                            BranchList.branches.get(i).mailbox.add(requestContent);
                        }
                    }

                    Toast.makeText(getApplicationContext(), "Request submitted successfully.", Toast.LENGTH_LONG).show();

                }
            }
        });



    }
}