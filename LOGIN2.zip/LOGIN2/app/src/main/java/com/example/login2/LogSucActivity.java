package com.example.login2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class LogSucActivity extends AppCompatActivity {
    TextView txt;
    TextView txtp;
    DatabaseHelper db;
    EditText startTime;
    EditText endTime;
    EditText serviceName;
    String timeOne;
    String timeTwo;
    String profileOutput;
    static ArrayList<String>profileContent = new ArrayList<String>(2);
    static ArrayList<Service> serviceContent = new ArrayList<Service>();
    Button setTime;
    Button addService;
    Button deleteService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_suc);
        db = new DatabaseHelper(this);
        txt = findViewById(R.id.textView3);
        txtp = findViewById(R.id.txtp);
        String name = db.getName();
        String identity = LoginActivity.identity;
        String text;
        text= ("Welcome "+name+"!"+"\n"+"\n"+"You are Registered as a(n) "+identity);
        txt.setText(txt.getText()+text);
        startTime = findViewById(R.id.startTime);
        endTime = findViewById(R.id.endTime);
        serviceName = findViewById(R.id.serviceName);
        setTime = findViewById(R.id.setTime);;
        addService = findViewById(R.id.addService);;
        deleteService = findViewById(R.id.deleteService);;
        if(profileContent.size() == 0){
            profileContent.add("NOT SET");
            profileContent.add("NOT SET");
        }

        setTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (startTime.getText().toString().equals("") || endTime.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Make sure you entered both the start time and end time", Toast.LENGTH_LONG).show();
                } else {
                    timeOne = startTime.getText().toString();
                    timeTwo = endTime.getText().toString();
                    profileContent.set(0, timeOne);
                    profileContent.set(1, timeTwo);
                    profileOutput = "";
                    setProfileOutput();
                }

                Toast.makeText(getApplicationContext(), "Work hours changed successfully.", Toast.LENGTH_LONG).show();
            }
            }
        );

        addService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(serviceName.getText().toString()==null){
                    Toast.makeText(getApplicationContext(), "Make sure you entered a service name", Toast.LENGTH_LONG).show();
                    return ;
                }

                Boolean exist1 = false;

                Boolean exist2 = false;

                for(int i = 0; i<profileContent.size();i++){
                    if (profileContent.get(i).toString().equals(serviceName.getText().toString())){
                        exist2 = true;
                        break;
                    }
                }

                for(int i = 0; i<adminSucActivity.services.size();i++){
                    if (adminSucActivity.services.get(i).name.toString().equals(serviceName.getText().toString())&& exist2 == false){
                        profileContent.add(adminSucActivity.services.get(i).name.toString());
                        serviceContent.add(adminSucActivity.services.get(i));
                        exist1 = true;
                        break;
                    }
                }



                if(exist2 == true){
                    Toast.makeText(getApplicationContext(), "This service is already set at the branch", Toast.LENGTH_LONG).show();
                } else if(exist1 == false){
                    Toast.makeText(getApplicationContext(), "This service is not provided by the Administrator", Toast.LENGTH_LONG).show();
                }
                else if(exist1 == true && exist2 == false){
                    profileOutput = "";
                    setProfileOutput();
                    Toast.makeText(getApplicationContext(), "Service added successfully", Toast.LENGTH_LONG).show();

                }

            }
        });

        deleteService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(serviceName.getText().toString()==null){
                    Toast.makeText(getApplicationContext(), "Make sure you entered a service name", Toast.LENGTH_LONG).show();
                    return ;
                }



                Boolean exist2 = false;


                for(int i = 0; i<profileContent.size();i++){
                    if (profileContent.get(i).toString().equals(serviceName.getText().toString())){
                        profileContent.remove(i);
                        serviceContent.remove(i-2);
                        exist2 = true;
                        break;
                    }
                }


                if(exist2 == false){
                    Toast.makeText(getApplicationContext(), "There is no such a service in the branch", Toast.LENGTH_LONG).show();
                }
                else if(exist2 == true){

                    profileOutput = "";
                   setProfileOutput();
                    Toast.makeText(getApplicationContext(), "Service removed successfully", Toast.LENGTH_LONG).show();

                }

            }
        });


    }

    public void setProfileOutput(){
        for(int i=0; i<profileContent.size(); i++) {
            if (i == 0) {
                profileOutput += "The working hours are from " + profileContent.get(i) + " to " + profileContent.get(i + 1);
            }

            if (i == 1) {
                profileOutput += "\n" + "\n" + "These services bellow are available at this branch now:  ";
            }

            if (profileContent.get(i) != null) {
                if (i >= 2) {
                    profileOutput += (i-1)+". "+profileContent.get(i) + " ";
                }
            }
        }
        txtp.setText( profileOutput);
    }

    }
