package com.example.login2;

public class Service {
    String name;
    String[] form;
    String[] documents;
    int id;
    public Service(String name,String[] form,  String[] documents){
        this.name = name;
        this.form = form;
        this.documents = documents;

    }
    public Service(int id){
        this.id = id;
    }
    public Service(String name){
        form = new String[30];
        this.name = name;
        documents = new String[30];
    }
}
